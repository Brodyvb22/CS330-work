from musical import create_app

application = create_app()
